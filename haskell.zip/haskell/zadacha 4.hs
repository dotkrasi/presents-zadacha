applyAndAdd f x = f x + x
multi5 x = x * 5

main = do
    let result = applyAndAdd sqrt 9   
    putStrLn (show (result)) 
    let result2 = applyAndAdd multi5 7
    putStrLn (show (result2))