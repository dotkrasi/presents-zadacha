sumOdd n =
    if n == 1
    then 1
    else (2 * n - 1) + sumOdd (n - 1)

main = do
    n <- getLine
    let num = read n :: Int
    putStrLn (show (sumOdd num))