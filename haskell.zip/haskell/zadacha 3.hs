max3 a b c =
        if a >= b && a >= c
        then a
        else if b >= a && b >= c
        then b
        else c

main = do
    num1 <- getLine
    num2 <- getLine
    num3 <- getLine
    let a  = read num1 :: Int
        b  = read num2 :: Int
        c1 = read num3 :: Int
    putStrLn (show (max3 a b c1))
