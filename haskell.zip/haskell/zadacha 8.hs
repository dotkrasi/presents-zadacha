sumEvenDigits x = sum x 0

sum n i =
    if n == 0
    then i
    else
        if n % 2 == 0
        then sum (n / 10) (i + (n / 10))
        else sum (n / 10) i 

