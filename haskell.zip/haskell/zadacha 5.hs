aritmetic n =
        if n == 1
        then n
        else aritmetic (n - 1) + 5


main = do
    n <- getLine
    let num = read n :: Int
    putStrLn (show (aritmetic num))